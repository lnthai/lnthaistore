<div class="row">
    <div class="col-md-12">
        <?php require("./app/views/res/" . $data['block'] . ".php"); ?>
    </div>

</div>