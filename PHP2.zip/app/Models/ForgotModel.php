<?php
namespace App\Models;
use App\Models\BaseModel;
class ForgotModel extends BaseModel{

}