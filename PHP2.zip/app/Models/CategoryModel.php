<?php
namespace App\Models;
use App\Models\BaseModel;
class CategoryModel extends BaseModel{
    
}